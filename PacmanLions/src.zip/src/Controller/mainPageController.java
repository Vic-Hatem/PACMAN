package Controller;

import Model.Config;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class mainPageController extends Application{

	
    @Override
	public void start(Stage primaryStage) throws Exception {
    	Config.Init(); //initializes node Definations
		try {
			Config.MainStage = new Stage();
			//Config.MainStage.setMaximized(true);
			
			//Parent root = FXMLLoader.load(getClass().getResource("/View/mainPage.fxml"));
			Config.HomeScene = new Scene(Config.root,Config.SizeX,Config.SizeY);
			
			
			Config.MainStage.setMaximized(true);
			Config.MainStage.setScene(Config.HomeScene);
			Config.MainStage.setTitle("Pacman");
			
			Config.MainStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	public synchronized static void main(String[] args) 
	{
		
			launch(args);

		
		
	}

}
