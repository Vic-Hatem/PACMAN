package View;

public class Pac_move {
	
	public void mov_up() 
	{
		System.out.println("Moving UP");
	}
	public void mov_down() 
	{
		System.out.println("Moving Down");

	}
	public void mov_left() 
	{
		System.out.println("Moving Left");

	}
	public void mov_right() 
	{
		System.out.println("Moving Right");

	}
}
